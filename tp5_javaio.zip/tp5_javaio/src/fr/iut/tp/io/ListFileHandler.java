package fr.iut.tp.io;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ListFileHandler implements FileHandler {

	List<File> FileList = new ArrayList<File>(); //Creating files list

	
	public List<File> getFileList() {
		return FileList;
	}


	public void setFileList(List<File> fileList) {
		this.FileList = fileList;
	}


	@Override
	public void HandleFile(File file) {
		FileList.add(file);

	}

}
