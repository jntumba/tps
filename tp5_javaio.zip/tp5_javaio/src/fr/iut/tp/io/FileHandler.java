package fr.iut.tp.io;

import java.io.File;

public interface FileHandler {
	
	public void HandleFile(File file);
}
