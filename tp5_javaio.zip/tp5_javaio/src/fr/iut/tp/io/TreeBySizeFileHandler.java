package fr.iut.tp.io;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class TreeBySizeFileHandler implements FileHandler {

	TreeMap<Long, List<File>> FileTreeMap = new TreeMap<Long, List<File>>();

	public TreeMap<Long, List<File>> getFileTreeMap() {
		return FileTreeMap;
	}

	public void setFileTreeMap(TreeMap<Long, List<File>> fileTreeMap) {
		FileTreeMap = fileTreeMap;
	}

	@Override
	public void HandleFile(File file) {
		List<File> ls = FileTreeMap.get(file.length());
		if (ls == null) {
			ls = new ArrayList<File>();
			FileTreeMap.put(file.length(), ls);
		}
		ls.add(file);
	}

	public void headSize() {
		int i = 0;
		//Sort keys taken from the TreeMap
		for (long key : FileTreeMap.descendingKeySet()) {
			//Creates a new list to 
			List<File> list = FileTreeMap.get(key);
			int j=0;
			while (i < 10 && j < list.size()) {
				System.out.println(key + " " + list.get(j));
				i++;
				j++;
			}
		}
	}
}
