package fr.iut.tp.io;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapByFullNameFileHandler implements FileHandler {

	Map<String, List<File>> FileMap = new HashMap<String, List<File>>();

	public Map<String, List<File>> getFileMap() {
		return FileMap;
	}

	public void setFileMap(Map<String, List<File>> fileMap) {
		FileMap = fileMap;
	}

	@Override
	public void HandleFile(File file) {
		List<File> ls = FileMap.get(file.getName());
		if (ls == null) {
			ls = new ArrayList<File>();
			FileMap.put(file.getName(), ls);
		}
		ls.add(file);
	}

	public void similarName(){
		//Look through Key elements of FileMap to find any similar name within files
		for (String sn : FileMap.keySet()){
			//If it finds any, displays them
			if(FileMap.get(sn).size() > 1 )
				System.out.println(FileMap.get(sn));
		}
	}
}
