package fr.iut.tp.io;

import java.io.File;

public class FileScanner {

	public void handleRecursively(File dir, FileHandler handler) {

		// Check every sub-dir and files
		for (File subDir : dir.listFiles()) {

			if (subDir.isFile())// Apply check on sub-dir to make sure
								// it's a file which'll callback
								// itself
				handler.HandleFile(subDir);
			else
				handleRecursively(subDir, handler);// Recursive check applied on
													// each sub-dir
		}
	}
	
}
