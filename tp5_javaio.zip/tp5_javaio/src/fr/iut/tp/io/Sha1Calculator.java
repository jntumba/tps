/*package fr.iut.tp.io;

public class Sha1Calculator {
	public byte()
                     }*/
