package fr.iut.tp.io;

import java.io.File;
/*import java.util.List;
import java.util.TreeMap;
import java.util.List;
import java.util.Map;*/

public class FileMain {
	public static void main(String[] args) {

		// FileScanner sc = new FileScanner();

		/*
		 * File dir = (args.length > 0)? new File(args[0]) : new File(".");
		 * //Look through the dir ListFileHandler lh = new ListFileHandler();
		 * new FileScanner(). handleRecursively(dir, lh); //Gets every files and
		 * sub-dir List<File> files = lh.getFileList();
		 * System.out.println("Files revealed" + files);
		 */

		/*File dir = (args.length > 0) ? new File(args[0]) : new File(".");
		MapByFullNameFileHandler mn = new MapByFullNameFileHandler();
		new FileScanner().handleRecursively(dir, mn);
		//Map<String, List<File>> files = mn.getFileMap();
		//System.out.println("Files revealed : \n" + files);
		mn.similarName();*/
		
		File dir = (args.length > 0) ? new File(args[0]) : new File(".");
		TreeBySizeFileHandler ts = new TreeBySizeFileHandler();
		new FileScanner().handleRecursively(dir, ts);
		ts.headSize();
	}
}
