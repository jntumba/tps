package fr.iut.tp.io;

import java.io.File;

public class PrintFileHandler implements FileHandler {

	@Override
	public void HandleFile(File file) {	
		System.out.println(file.getName()); //Display names of files
	}

}
